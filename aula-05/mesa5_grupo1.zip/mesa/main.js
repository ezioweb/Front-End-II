let mudarCor = document.querySelector('button')
let body = document.querySelector('body')

function trocarCor() {
    body.classList.toggle('dark')
}
